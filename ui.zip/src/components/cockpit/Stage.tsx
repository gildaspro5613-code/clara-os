/**
 * ============================================
 * CLARA OS
 * Cockpit Module
 * --------------------------------------------
 * File : Stage.tsx
 * Responsibility :
 * Official cockpit composition.

 * Reproduces cockpit_master.png.
 * No business logic.
 * ============================================
 */

import AttentionPanel from "./panels/AttentionPanel";
import TodayPanel from "./panels/TodayPanel";
import TasksPanel from "./panels/TasksPanel";
import SummaryPanel from "./panels/SummaryPanel";
import ConversationsPanel from "./panels/ConversationsPanel";
import QuickActionsPanel from "./panels/QuickActionsPanel";

export default function Stage() {
  return (
    <div className="pointer-events-none absolute inset-0 z-20">

      {/* ===== COLONNE GAUCHE ===== */}

      <div
        className="absolute"
        style={{
          top: "90px",
          right: "610px",
          width: "280px",
        }}
      >
        <AttentionPanel />
      </div>

      <div
        className="absolute"
        style={{
          top: "285px",
          right: "610px",
          width: "280px",
        }}
      >
        <TodayPanel />
      </div>

      <div
        className="absolute"
        style={{
          top: "540px",
          right: "610px",
          width: "280px",
        }}
      >
        <TasksPanel />
      </div>

      {/* ===== COLONNE DROITE ===== */}

      <div
        className="absolute"
        style={{
          top: "90px",
          right: "80px",
          width: "290px",
        }}
      >
        <SummaryPanel />
      </div>

      <div
        className="absolute"
        style={{
          top: "390px",
          right: "80px",
          width: "290px",
        }}
      >
        <ConversationsPanel />
      </div>

      <div
        className="absolute"
        style={{
          top: "700px",
          right: "80px",
          width: "290px",
        }}
      >
        <QuickActionsPanel />
      </div>

    </div>
  );
}