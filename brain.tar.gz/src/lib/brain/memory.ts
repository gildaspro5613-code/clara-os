// src/lib/brain/memory.ts

import { BrainMemory } from "./types";

/**
 * Initialise la mémoire du Brain.
 */
export function createMemory(): BrainMemory {
  return {
    shortTerm: [],
    longTerm: [],
    facts: {},
  };
}

/**
 * Ajoute une information à la mémoire court terme.
 */
export function remember(
  memory: BrainMemory,
  information: string
): BrainMemory {
  return {
    ...memory,
    shortTerm: [...memory.shortTerm, information],
  };
}

/**
 * Archive une information dans la mémoire long terme.
 */
export function archive(
  memory: BrainMemory,
  information: string
): BrainMemory {
  return {
    ...memory,
    longTerm: [...memory.longTerm, information],
  };
}

/**
 * Enregistre un fait structuré.
 */
export function rememberFact(
  memory: BrainMemory,
  key: string,
  value: unknown
): BrainMemory {
  return {
    ...memory,
    facts: {
      ...memory.facts,
      [key]: value,
    },
  };
}

/**
 * Recherche un fait.
 */
export function recallFact<T = unknown>(
  memory: BrainMemory,
  key: string
): T | undefined {
  return memory.facts[key] as T | undefined;
}

/**
 * Efface la mémoire court terme.
 */
export function clearShortTerm(memory: BrainMemory): BrainMemory {
  return {
    ...memory,
    shortTerm: [],
  };
}