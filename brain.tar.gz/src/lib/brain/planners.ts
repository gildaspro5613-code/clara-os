// src/lib/brain/planners.ts

import {
  BrainAction,
  BrainPriority,
  BrainReasoning,
} from "./types";

/**
 * Génère un plan d'actions à partir du raisonnement
 * et des priorités calculées.
 */
export function planActions(
  reasoning: BrainReasoning,
  priorities: BrainPriority[]
): BrainAction[] {
  const actions: BrainAction[] = [];

  switch (reasoning.intent) {
    case "create":
      actions.push({
        id: crypto.randomUUID(),
        title: "Créer une nouvelle ressource",
        description: reasoning.summary,
        priority: 100,
        completed: false,
      });
      break;

    case "update":
      actions.push({
        id: crypto.randomUUID(),
        title: "Mettre à jour la ressource",
        description: reasoning.summary,
        priority: 90,
        completed: false,
      });
      break;

    case "delete":
      actions.push({
        id: crypto.randomUUID(),
        title: "Demander une confirmation",
        description: "Suppression potentiellement destructive.",
        priority: 100,
        completed: false,
      });
      break;

    case "search":
      actions.push({
        id: crypto.randomUUID(),
        title: "Rechercher les informations",
        description: reasoning.summary,
        priority: 70,
        completed: false,
      });
      break;

    case "analyze":
      actions.push({
        id: crypto.randomUUID(),
        title: "Analyser les données",
        description: reasoning.summary,
        priority: 80,
        completed: false,
      });
      break;

    default:
      actions.push({
        id: crypto.randomUUID(),
        title: "Poursuivre la conversation",
        description: reasoning.summary,
        priority: 50,
        completed: false,
      });
  }

  // Ajuste les priorités si elles existent déjà
  return actions.map((action) => {
    const existing = priorities.find((p) => p.label === action.title);

    if (!existing) {
      return action;
    }

    return {
      ...action,
      priority: Math.max(action.priority, existing.score),
    };
  });
}