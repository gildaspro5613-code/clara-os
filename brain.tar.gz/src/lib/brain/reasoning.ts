// src/lib/brain/reasoning.ts

import { BrainContext, BrainReasoning } from "./types";

/**
 * Analyse une requête utilisateur et produit
 * une première compréhension structurée.
 */
export function reason(
  context: BrainContext
): BrainReasoning {
  const input = context.input.trim();

  return {
    intent: detectIntent(input),
    confidence: estimateConfidence(input),
    summary: summarize(input),
    entities: extractEntities(input),
    nextStep: determineNextStep(input),
  };
}

/**
 * Détection simple de l'intention.
 * Cette fonction pourra être remplacée plus tard
 * par un raisonnement piloté par un LLM.
 */
function detectIntent(text: string): string {
  const value = text.toLowerCase();

  if (value.includes("créer")) return "create";
  if (value.includes("modifier")) return "update";
  if (value.includes("supprimer")) return "delete";
  if (value.includes("analyser")) return "analyze";
  if (value.includes("chercher")) return "search";

  return "conversation";
}

/**
 * Estimation de confiance.
 */
function estimateConfidence(text: string): number {
  if (text.length > 40) return 0.95;
  if (text.length > 15) return 0.85;
  return 0.70;
}

/**
 * Résumé minimal.
 */
function summarize(text: string): string {
  return text.length <= 120
    ? text
    : `${text.substring(0, 117)}...`;
}

/**
 * Extraction très simple d'entités.
 */
function extractEntities(text: string): string[] {
  return text
    .split(/\s+/)
    .filter((word) => word.length > 3)
    .map((word) => word.replace(/[^\p{L}\p{N}]/gu, ""));
}

/**
 * Détermine l'étape suivante.
 */
function determineNextStep(intent: string): string {
  switch (detectIntent(intent)) {
    case "create":
      return "planner";

    case "update":
      return "planner";

    case "delete":
      return "confirmation";

    case "search":
      return "knowledge";

    case "analyze":
      return "analysis";

    default:
      return "conversation";
  }
}